#include "/home/coolsamurai/Cpp/projects/drones_system/include/state.hpp"

/* Constructor */
State::State(const std::string& cities_source, const std::string& graph_source)
   : cities_source_(cities_source), graph_source_(graph_source) {}


/* ********************************
 * Accessors: Thread-safe accessors
 * ******************************** */

// flags
std::atomic<bool>& State::get_running()
{
   return running;
}
std::atomic<bool>& State::get_paused()
{
   return paused;
}
std::atomic<bool>& State::get_resumed()
{
   return resumed;
}

// data
const std::string& State::get_cities_source()
{
   return cities_source_;
}
const std::string& State::get_graph_source()
{
   return graph_source_;
}