#include "../include/good.hpp"

/* Note: the SHORT and TIME data types have been defined in the "custom_data.hpp" file! */
Good::Good(int id,
           std::shared_ptr<Node>& origin,
           std::shared_ptr<Node>& destination,
           float weight,
           std::chrono::steady_clock::time_point generated_time,
           State& state)
    : id(id),
    origin(origin),
    destination(destination),
    weight(weight),
    generated_time(generated_time),
    state(state)
{

    generates_path(origin, destination);
}

// utility function
void Good::generates_path(std::shared_ptr<Node>& origin_id, std::shared_ptr<Node>& destination_id)
{
    state.with_graph([&](Distance_matrix &graph, std::vector<std::shared_ptr<Node>> &nodes){
        // The initialization phase, we just make the map with each city has INF estimate of traveled distance
        // and the prev city is null and takes the node id as what it is for each node in NODES_IN_SYSTEM

        float INF = std::numeric_limits<float>::infinity();    // Infinite value;
        auto cities = CITIES;

        /* Dijkstra's algorithm begins here! */

        // step 1: initializing the first node, aka the node at the beginning of the path. the starting city
        auto& start = cities[origin_id];
        start.estimate = 0.0;

        // generating the priority queue
        using QueueElement = std::pair<float, std::shared_ptr<Node>>;
        std::priority_queue<QueueElement, std::vector<QueueElement>, std::greater<QueueElement>> pq;
        pq.emplace(0.0, origin_id);

        // step 2: looping through the priority queue!
        while(!pq.empty())
        {
           auto [current_dist, u] = pq.top();
           pq.pop();

           // checks if the picked node is explored!
           auto& current_node = cities[u];
           if (current_node.explored) continue;
           current_node.explored = true;

           // Early exist if the destination is reached
           if (u == destination_id) break;

           for (auto& v : current_node.neighbors)
           {
              auto& neighbor = cities[v];
              if(neighbor.explored) continue;

              // updating the distance to v neighbor.
              float edge_weight = graph.get_distance(u->get_id(), v->get_id());
              float new_estimate = current_dist + edge_weight;

              if (new_estimate < neighbor.estimate)
              {
                 neighbor.estimate = new_estimate;
                 neighbor.prev = u;
                 pq.emplace(new_estimate, v);
              }
           }
        }

        // generating the path by going backward!
        auto& node = cities[destination_id];
        path.insert(path.begin(), Path(node.node->get_id(), false));
        while (node.prev)
        {
           path.insert(path.begin(), Path(node.prev->get_id(), false));
           node = cities[node.prev];
        }

    });
}

// getters
int Good::get_id() const
{
    return id;
}
std::shared_ptr<Node>& Good::get_origin() const
{
    return origin;
}
std::shared_ptr<Node>& Good::get_destination() const
{
    return destination;
}
std::chrono::steady_clock::time_point Good::get_generated_time() const
{
    return generated_time;
}
float Good::get_weight() const
{
    return weight;
}
std::vector<Path>& Good::get_path()
{
    return path;
}