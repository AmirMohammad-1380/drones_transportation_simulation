#include "../include/simulation.hpp"

Simulation::Simulation(int duration, std::string& cities_source, std::string& graph_source, size_t num_threads)
   : state(cities_source, graph_source),
     init(state),
     timer(duration, state.get_running(), state.get_paused(), state.get_resumed()),
     pool(num_threads) {}

/* simulation implementation */
void Simulation::sim_run()
{
   /* **********************************
    * initializes the simulation
    * 1- loads the distances
    * 2- generates the graph
    * 3- generates drones for each node
    * 4- generates goods for each node
    * ********************************** */

   /* timer and flags methods, via threads begins here */
   auto future_tiktok = pool.enqueue(&Timing::tik_tok, &timer);
   auto future_flags = pool.enqueue(&Timing::flags, &timer);

   /* as long as the 'running' flag is true -> simulation keeps running */
   while(state.get_running().load(std::memory_order_acquire))
   {
      /* if user pauses the simulation */
      if (state.get_paused().load(std::memory_order_acquire))
      {
         /* as long as user has not resumed the simulation we keeps pausing! */
         while (!state.get_resumed().load(std::memory_order_acquire)) {
            /* optimizing cpu usage */
            std::this_thread::sleep_for(100ms);

         }

         /* at this point user has resumed the simulation, therefore we reset the flags */
         state.get_paused().store(false, std::memory_order_release);
         state.get_resumed().store(false, std::memory_order_release);
      }

      /* *******************************
       * rest of simulation begins here!
       * ******************************* */

      auto tasks = drone_task.get_task_map();
      auto current_origin = std::shared_ptr<Node>();
      auto next_destination = std::shared_ptr<Node>();

      /* the following will make dictionary with key of each node! with a value of another dictionary
       * that point to the next destination of the list of goods as the inner dictionary's value! */
      state.with_goods([&](std::vector<std::shared_ptr<Good>> &goods, std::vector<std::shared_ptr<Node>> &nodes){
          for (auto &good : goods) {
             auto &path = good->get_path();

             /* Note the first node of the path is node that good is at! so make as explored: 'explored = true' */
             if (!path.front().explored) {
                current_origin = get_node_by_id(path.front().node_id, nodes);
                path.front().explored = true;
                for (auto &path_element: path) {
                   if (!path_element.explored) {
                      next_destination = get_node_by_id(path_element.node_id, nodes);
                      tasks[current_origin][next_destination].goods.push_back(good);
                      tasks[current_origin][next_destination].delivered = false;
                      break;
                   }
                }
                continue;
             }

             /* looping through the rest of the path to check the next_destination of the good */
             for (auto path_origin = path.begin(); (path_origin + 1) != path.end() ; ++path_origin)
             {
                if (path_origin->explored && !(path_origin + 1)->explored)
                {
                   current_origin = get_node_by_id(path_origin->node_id, nodes);
                   next_destination = get_node_by_id((path_origin + 1)->node_id, nodes);
                   tasks[current_origin][next_destination].goods.push_back(good);
                   break;
                }
             }
          }
      });

      /* looping through the drones and find the proper load */
      state.with_drones([&](std::vector<std::shared_ptr<Drone>> &drones, std::vector<std::shared_ptr<Node>> &nodes){
          for (auto &drone : drones)
          {
             /* to handle simulation flags during drones loading process */
             // if user quits the simulation
             if (!state.get_running().load(std::memory_order_acquire))
             {
                pool.ThreadPool_shutdown();
                break;
             }

             // if user pauses the simulation
             if (state.get_paused().load(std::memory_order_acquire))
             {
                while (!state.get_resumed().load(std::memory_order_acquire))
                {
                   std::this_thread::sleep_for(100ms);
                }

                state.get_paused().store(false, std::memory_order_release);
                state.get_resumed().store(false, std::memory_order_release);
             }

             current_origin = drone->get_landed_node();
             auto origin_it = tasks.find(current_origin);
             if (origin_it != tasks.end())
             {
                if (tasks[current_origin].empty())
                {
                   continue;
                }

                // map destination with common origin of current_origin
                auto &destinations = origin_it->second;
                if(destinations.empty())
                {
                   throw std::runtime_error("[Error - Simulation - sim_run() - line:150] | empty dictionary!");
                }
             }

             /* checks if all the next_dest of with current_origin are delivered */
             bool fully_delivered = true;
             for (auto &next_dest : tasks[current_origin])
             {
                if (!next_dest.second.delivered)
                {
                   /* if only on of the next_dest has not been delivered */
                   fully_delivered = false;
                   break;
                }
             }

             if (fully_delivered)
             {
                /* goes for the next drone! with different current_origin */
                continue;
             }

             /* we reach here if at least on destination with current_origin has left to delivery */
             for (auto &next_dest : tasks[current_origin])
             {
                if(next_dest.second.delivered)
                {
                   /* goods from current_origin to next_destination already delivered! */
                   continue;
                }
                else
                {
                   /* we take the next destination if that drone! */
                   next_destination = next_dest.first;
                   drone->set_next_destination(next_destination);
                   break;
                }
             }

             /* ***************************************************
             * now we know the origin and destination of the drone
             * *************************************************** */

             /* first we check for drone type!
             * 1- large type->hubs
             * 2- medium type->hubs - subhubs
             * 3- small type->subhubs - spokes */
             auto config = state.get_config();
             auto hub = config.node_config.type_hub;
             auto subhub = config.node_config.type_sub_hub;
             auto spoke = config.node_config.type_spoke;

             auto large_drone = config.drone_config.large.type_name;
             auto medium_drone = config.drone_config.medium.type_name;
             auto small_drone = config.drone_config.small.type_name;

             /* large drones travels only between hubs */
             if(drone->get_type() == large_drone && next_destination->get_type() != hub)
             {
                // wrong drone => we go for next drone!
                continue;
             }
                /* medium drones travels between hubs and subhubs */
             else if (drone->get_type() == medium_drone)
             {
                if (current_origin->get_type() == hub && next_destination->get_type() == hub)
                {
                   // wrong drone!
                   continue;
                }
                else if (current_origin->get_type() == subhub && next_destination->get_type() == spoke)
                {
                   // wrong drone!
                   continue;
                }
             }
                /* small srones travels only between subhub and spokes */
             else if (drone->get_type() == small_drone)
             {
                if (current_origin->get_type() == subhub && next_destination->get_type() == hub)
                {
                   // wrong drone!
                   continue;
                }
             }

             /* with a proper drone selected */
             /* taking the flight distance */
             float flight_distance;
             state.with_graph([&](Distance_matrix &graph, std::vector<std::shared_ptr<Node>> &nodes){
                flight_distance = graph.get_distance(
                   current_origin->get_id(), next_destination->get_id()
                );
             });

             // checks if drone can travel the distance!
             if (!drone->can_travel(flight_distance))
             {
                // adds the overhaul function to the pool for execution
                pool.enqueue(&Drone::overhaul, drone);
                continue;
             }

             /* *****************************************************************************
              * at this point
              * 1- the current_origin and next_destination has been determined
              * 2- the drone's type correctness has been qualified
              * 3- the drone can travel the distance from current_origin to next_destination
              * and ready to load proper goods from current_origin to next_destination
              * ***************************************************************************** */
             auto &goods_list = tasks[current_origin][next_destination].goods;
             for (auto &gd : goods_list)
             {
                if (!state.get_running().load(std::memory_order_acquire))
                {
                   pool.ThreadPool_shutdown();
                   break;
                }

                if (!gd)
                {
                   throw std::runtime_error("[Error - Simulation - sim_run()] | gd is nullptr! -> no more good with common destination");
                   continue;
                }

                if (drone->can_carry(gd->get_weight()))
                {
                   drone->load(gd);
                }
             }

             /* marks these goods with next_destination delivered successfully */
             tasks[current_origin][next_destination].delivered = true;

             for (auto &good : tasks[current_origin][next_destination].goods)
             {
                for (auto &path : good->get_path())
                {
                   if (!path.explored)
                   {
                      path.explored = true;
                      break;
                   }
                }
             }

             /* drone is now loaded, and ready to take flight */
             pool.enqueue(&Drone::delivery, drone, flight_distance);
          }
      });

      /* Super Important:
       * we add the process of removing of goods completely delivered to final destination
       * to the end of pool!
       * to make sure all the drones in flight would finally land and then check for removal process */

      auto remove_future = pool.enqueue(&Simulation::remove_complete_deliverance_goods, this);
      remove_future.get();


      init.initial_drones();
      init.initial_goods();
   }

   /* at the end calculates the final result, which is the average time of complete deliverance! */
   auto result_future = pool.enqueue(&Simulation::calculates_average_time, this);
   result_future.get();
}
















































void Simulation::removal_process(std::vector<std::shared_ptr<Good>> to_remove, std::vector<std::shared_ptr<Good>> &goods)
{
   for (std::shared_ptr<Good> rem_gd : to_remove)
   {
      goods.erase(
         std::remove_if(
            goods.begin(), goods.end(), [rem_gd](const std::shared_ptr<Good>& other_good) -> bool{
               return rem_gd->get_id() == other_good->get_id();
            }
         ), goods.end()
      );
   }
}

std::shared_ptr<Node> Simulation::get_node_by_id(uint16_t node_id, std::vector<std::shared_ptr<Node>> &nodes)
{
   auto it = std::find_if(
      nodes.begin(), nodes.end(), [node_id](const std::shared_ptr<Node>& other_node){
         return node_id == other_node->get_id();
      }
   );
   if (it == nodes.end())
   {
      throw std::runtime_error("[Error - Simulation - get_node_by_id()] | couldn't find node by id!");
   }
   return *it;
}

void Simulation::remove_complete_deliverance_goods()
{
   state.with_goods([&](std::vector<std::shared_ptr<Good>> &goods, std::vector<std::shared_ptr<Node>> &nodes){
       /* goods to remove! */
       std::vector<std::shared_ptr<Good>> to_remove;

       /* looping through each node to find those that has reached their final destination */
       for (auto& good : goods)
       {
          /* takes the path of the good */
          auto& path = good->get_path();

          /* checks if the good has reached the final destination */
          if (path.back().explored)
          {
             /* adds the delivery duration of the good! to calculate the average time of deliverance */
             auto deliverance =
                     std::chrono::duration_cast<std::chrono::seconds>(
                             std::chrono::steady_clock::now() - good->get_generated_time());

             /* prints the arrival of the current good */
             std::cout << green << "[Deliverance Completed]"
                       << reset << " | "
                       << red << "[Good] : "
                       << yellow << "[Origin"
                       << reset << " : "
                       << yellow << good->get_origin()->get_name() << "]"
                       << reset << " -> "
                       << magenta << "[Destination"
                       << reset << " : "
                       << magenta << good->get_destination()->get_name() << "]"
                       << reset << '\n'
                       << std::flush;


             /* adds the deliverance duration to the '_deliverance_time' list*/
             _deliverance_times.push_back(static_cast<long>(deliverance.count()));

             to_remove.push_back(good);
          }
       }

       /* removes the goods that has reached their destination */
       // prevent extra use of 'removal_process()' if there's no goods to remove
       if (!to_remove.empty())
       {
          removal_process(to_remove, goods);
          to_remove.clear();
       }
   });
}

void Simulation::calculates_average_time()
{
   /* calculates Deliverance Average Time: measured in seconds */
   auto times_list_length = _deliverance_times.size();
   long sum = 0;
   for (auto time : _deliverance_times)
   {
      sum += time;
   }
   auto AverageTime = static_cast<int>(std::round(sum / times_list_length));

   /* locks for clean log message on terminal */
   {
      std::lock_guard<std::mutex> lock(guard);

      /* prints the final result */
      std::cout << green << "[Final Result]"
                << reset <<" | "
                << yellow << "[Average of Complete Deliverance]"
                << reset << " -> "
                << bright_white << "[" << AverageTime << " sec]" << reset
                << std::flush;

   } // lock is releases here automatically
}

void Simulation::redistrbute_drones()
{
   state.with_drones([&](std::vector<std::shared_ptr<Drone>> &drones, std::vector<std::shared_ptr<Node>> &nodes)
   {
      for (auto drone = drones.begin(); drone != drones.end(); ++drone)
      {
         drones.erase(drone);
      }
   });

   init.initial_drones();
}

