#include "/home/coolsamurai/Cpp/projects/drones_system/include/timing.hpp"

Timing::Timing(int duration,
               std::atomic<bool>& running,
               std::atomic<bool>& paused,
               std::atomic<bool>& resumed
               ) : duration(duration),
               running(running),
               paused(paused),
               resumed(resumed) {}

void Timing::tik_tok()
{
   // calculates the end point in seconds!
   auto end_time = std::chrono::steady_clock::now() + std::chrono::seconds(duration);

   // marks that timer has started counting the time.
   print("Tik Tok - Tik Tok - ...", ' ');

   /* keep counting time in seconds as long as the flag 'running' is true */
   while (running.load(std::memory_order_acquire))
   {
      if (paused.load(std::memory_order_acquire))
      {
         /* ******************************************
          * 1- calculates the pause duration
          * 2- waits until user resumes the simulation
          * ****************************************** */
         auto pause_begins = std::chrono::steady_clock::now();
         while (!resumed.load(std::memory_order_acquire))
         {
            // done for CPU usage optimization
            std::this_thread::sleep_for(500ms);
         }
         auto pause_ends = std::chrono::steady_clock::now();

         // calculates the pause duration
         auto pause_duration = std::chrono::duration_cast<std::chrono::seconds>(pause_ends - pause_begins);

         // updates the end_time!
         end_time += pause_duration;

         // updates the flags
         paused.store(false, std::memory_order_release);
         resumed.store(false, std::memory_order_release);
      }

      // checks if the simulation has met end of time, aka time is over!
      if (std::chrono::steady_clock::now() >= end_time)
      {
         print("Time's up", 'g');
         running.store(false, std::memory_order_release);
         return;
      }

      // CPU usage optimization:
      std::this_thread::sleep_for(100ms);
   }
}
void Timing::flags()
{
   /* ***********************************************************
    * the following will change the default C++ input system from
    * blocking-mode to a non-blocking mode
    * *********************************************************** */
   // takes the flags

   char chr;

   int flag = fcntl(STDIN_FILENO, F_GETFL, 0);
   if (flag == -1)
   {
      // Error to reading the flag
      print("[Error - Timing - flags] | Failed to get file flags!", 'r');
      running.store(false, std::memory_order_release);
      return;
   }

   // Sets to non-blocking mode!
   if (fcntl(STDIN_FILENO, F_SETFL, flag | O_NONBLOCK) == -1)
   {
      // Error: failing to set non-blocking mode
      print("[Error - Timing - flags] | Failed to set non-blocking mode", 'r');
      running.store(false, std::memory_order_release);
      return;
   }

   // Always keeps running behind the hood to capture a flag from user!
   while (running.load(std::memory_order_acquire))
   {
      // takes the input: using how we do in C language.
      ssize_t n = read(STDIN_FILENO, &chr, 1);

      if (n > 0)
      {
         // user wants to quit the simulation, aka tik_tok timer
         if (chr == 'q')
         {
            /* ***********************************************************************************
             * to be cautious, after capturing 'q' flag, asks a question from user to make sure
             * user truly wants to quit, and it was not sudden mistake pressing q
             * 1 - temporarily turn back the input system from non-blocking mode to blocking mode
             * 2 - the simulation must get paused during this question!
             * 3 - asks question and executes based on user response
             * 4 - returns the input system back to non-blocking mode
             * *********************************************************************************** */

            // asks question and pauses the simulation
            print("Are you sure to quit and terminate the simulation? [Y/N]", 'y');
            paused.store(true, std::memory_order_release);

            // takes the file flags
            int old_flag = fcntl(STDIN_FILENO, F_GETFL, 0);
            if (old_flag == -1)
            {
               print("[Error - Timing - flags:turning blocking mode] | Failed to get file flags", 'r');
               resumed.store(true, std::memory_order_release);
               continue;
            }

            // sets the input system to blocking-mode
            if (fcntl(STDIN_FILENO, F_SETFL, old_flag & ~O_NONBLOCK) == -1)
            {
               print("[Error - Timing - flags:turning blocking mode] | Failed to set blocking mode", 'r');
               resumed.store(true, std::memory_order_release);
               continue;
            }

            // takes the answer
            char answer;
            std::cin >> answer;

            // flushes any remaing input in the terminal
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

            // checks if user entered proper answer, aka an alphabetical character.
            while (!std::isalpha(answer))
            {
               print("Please answer with a 'Y' as yes or 'N' as no", 'y');
               std::cin >> answer;

               // flushes any remaining input in the terminal
               std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }

            // checks for answer
            // if the answer is yes
            if (std::tolower(answer) == 'y')
            {
               print("User quits and terminates the simulation!", 'b');
               running.store(false, std::memory_order_release);
               resumed.store(true, std::memory_order_release);
               return;
            }
            //if the answer is no
            else if (std::tolower(answer) == 'n')
            {
               print("User regrets to quit and terminate the simulation!", 'b');
               resumed.store(true, std::memory_order_release);
            }
            else
            {
               print("Invalid: not a [Y/N]! | simulation resumed by default!", 'n');
               resumed.store(true, std::memory_order_release);
            }

            // turns back the input system to non-blocking mode!
            fcntl(STDIN_FILENO, F_SETFL, old_flag);
         }
         // user wants to pause the simulation, aka tik_tok timer
         else if (chr == 'p')
         {
            print("User paused the simulation!", 'y');
            paused.store(true, std::memory_order_release);
         }
         // user want to resume the simulation, aka tik_tok timer
         else if (chr == 'r')
         {
            print("User resumed the simulation!", 'y');
            resumed.store(true, std::memory_order_release);
         }
      }
      // sleeps the thread to be CPU optimized
      std::this_thread::sleep_for(100ms);
   }
}
void Timing::print(const std::string& str_, const char& color_) {
   /* locks to be thread-safe */
   std::lock_guard<std::mutex> lock(util_mutex);

   /* determines the color and prints the str based on that color */
   switch (color_) {
      case 'r':
         std::cout << red << str_ << reset << '\n';
         break;
      case 'g':
         std::cout << green << str_ << reset << '\n';
         break;
      case 'y':
         std::cout << yellow << str_ << reset << '\n';
         break;
      case 'b':
         std::cout << blue << str_ << reset << '\n';
         break;
      default:
         std::cout << reset << str_ << reset << '\n';
   }
// locks is released here!
}