#include "/home/coolsamurai/Cpp/projects/drones_system/include/ThreadPool.hpp"

ThreadPool::ThreadPool(size_t num_threads) : stop(false)
{
    for (size_t i = 0; i < num_threads; i++)
    {
        workers.emplace_back([this] {
            while (true)
            {
                // stores the next task
                std::function<void()> task;

                // locks the tasks queue to be thread safe and takes task from there
                {
                    // locks the queue to be thread safe
                    std::unique_lock<std::mutex> lock(queue_mutex);

                    /* wait until:
                     * there's task to do in tasks queue
                     * or
                     * the pool is stopping */
                    this->condition.wait(lock, [this] {
                        return this->stop || !this->tasks.empty();
                    });

                    // if stopping and no tasks is available
                    if (this->stop && this->tasks.empty())
                    {
                        // stops the thread and terminate it
                        return;
                    }

                    // grabs the next task from the queue to execute and delete it from the queue
                    task = std::move(this->tasks.front());
                    tasks.pop();

                } // lock is released here automatically

                // executes the task
                task();
            }
        });
    }
}

ThreadPool::~ThreadPool()
{
    // sets stop as true: stop = true
    {
        // lock the queue to be thread safe
        std::unique_lock<std::mutex> lock(queue_mutex);

        // stop = true
        stop = true;
    } // lock is released here automatically

    // notifies all the threads about 'stop' changes
    condition.notify_all();

    // waits till all threads finish their ongoing task
    for (std::thread& worker : workers)
    {
        if (worker.joinable())
        {
            worker.join();
        }
    }
}

void ThreadPool::ThreadPool_shutdown()
{
   std::unique_lock<std::mutex> lock(queue_mutex);
   stop = true;
}
