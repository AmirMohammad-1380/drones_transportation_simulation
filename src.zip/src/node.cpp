#include "../include/node.hpp"

Node::Node(uint16_t& id, std::string& name, std::string& type)
    : id(id), name(name), type(type) {}

const uint16_t& Node::get_id() const
{
    return id;
}
const std::string& Node::get_name() const
{
    return name;
}
const std::string& Node::get_type() const
{
    return type;
}
std::vector<std::shared_ptr<Drone>>& Node::get_drones()
{
    return drones;
}

// setters
void Node::set_id(uint16_t& id)
{
    this->id = id;
}
void Node::set_name(std::string& name)
{
    this->name = name;
}
void Node::set_type(std::string& type)
{
    this->type = type;
}

bool Node::operator==(const Node &other)
{
    return id == other.get_id() &&
        name == other.get_name() &&
        type == other.get_type();
}