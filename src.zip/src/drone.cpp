#include "../include/drone.hpp"

Drone::Drone(int id,
             const std::string& type,
             float max_distance,
             float max_capacity,
             float speed,
             const std::shared_ptr<Node>& landed_node,
             State& state) :
             id(id),
             type(std::move(type)),
             max_distance(max_distance),
             max_capacity(max_capacity),
             speed(speed),
             landed_node(std::move(landed_node)),
             state(state),
             next_destination(nullptr),
             distance_traveled(0.0),
             current_load(0.0) {}

// utility functions
bool Drone::can_travel(float distance)
{
    // returns true, if the traveled distance + given distance: is equal or less than the max distance the drone can travel!.
    if (distance_traveled + distance <= max_distance) {return true;}
    return false;
}
bool Drone::can_carry(float weight)
{
    // returns true, if the sum of current weights loaded on the drone with the given weight is less than or equal to the max capacity the drone can carry!
    if (current_load + weight <= max_capacity) {return true;}
    return false;
}
void Drone::load(std::shared_ptr<Good>& good)
{
   std::lock_guard<std::mutex> lock(lock_mutex_);

   // updates the current load.
   current_load += good->get_weight();
}
void Drone::delivery(float distance)
{
   // drone's flight begins.
   travel(distance);

   /* locks for clean logging */
   {
      std::unique_lock<std::mutex> lock(lock_mutex_);
      std::cout << bright_red << "[Landing]"
                << reset <<  " | "
                << bright_cyan << "[Drone]"
                << reset <<" : "
                << cyan << "(id " << reset << " > " << cyan << id << ")"
                << reset << " : " << cyan << "Type " << " > " << cyan << type << ")"
                << reset << " | "
                << magenta << "[Port]"
                << reset << " : "
                << magenta << "(Name" << reset << " > " << magenta << next_destination->get_name() << ")"
                << reset " : "
                << magenta << "(id" << reset << " > " << magenta << next_destination->get_id() << ")"
                << reset << " : "
                << magenta << "(Type" << reset << " > " << magenta << next_destination->get_type() << ")"
                << reset << " | "
                << "[Cargo: " << current_load << "kg]\n" << reset
                << std::flush;

   } // lock is released automatically here

   // setting the drone for the landed_node!
   landed_node = std::move(next_destination); // the landed_node of the drone gets updated here.
   next_destination = nullptr;
   loaded_goods.clear(); // the drone's loaded_goods list gets clear and becomes empty.
   current_load = 0.0; // the drone's current_loads gets reset to 0.
}
void Drone::travel(float distance)
{
   // calculates travel time.
   int travel_time = static_cast<int>(std::round(distance / speed));

   distance_traveled += distance;

   // lock for clean logging
   {
      std::unique_lock<std::mutex> lock(lock_mutex_);
      std::cout << bright_green <<"[Flight]"
                << reset <<" | "
                << bright_cyan << "[Drone] "
                << cyan << "(id " << reset << " > " << cyan << id << ")"
                << reset << " : " << "(Type " << " > " << cyan << type << ")"
                << reset << " && "
                << yellow <<" [Origin] "
                << "(Name" << reset << " > " << yellow << landed_node->get_name() << ")"
                << reset << " : "<< "(id " << reset << " > " << yellow << landed_node->get_id() << ")"
                << reset << " : " << yellow << "(Type " << reset << " > " << yellow << landed_node->get_type() << ")"
                << reset << " -> "
                << magenta << "[Destination]"
                << "(Name " << reset << " > " << magenta << next_destination->get_name() << ") "
                << reset << " : " << magenta << "(id " << reset << " > " << magenta << next_destination->get_id() << ")"
                << reset << " : " << magenta << "(Type " << " > " << magenta << next_destination->get_type() << ")"
                << reset << " | "
                << "[Duration: " << travel_time << " seconds]\n" << reset
                << std::flush;

   } // lock is released automatically here

   // sleeps this thread as simulating the drone's flight duration!
   std::this_thread::sleep_for(std::chrono::seconds(travel_time));
}
void Drone::overhaul()
{
   const auto& _config_ = state.get_config();
    if (type == _config_.drone_config.large.type_name)
    {
        // takes around 15 seconds to repair. with deviation of 5 seconds
        repair(15);
    }
    else if (type == _config_.drone_config.medium.type_name)
    {
        // takes around 12 seconds to repair. with deviation of 5 seconds
        repair(12);
    }
    else // for small drones
    {
        // takes around 10 seconds to repair. with deviation of 5 seconds
        repair(10);
    }
}
void Drone::repair(int repair_time)
{
   std::lock_guard<std::mutex> lock(lock_mutex_);

   // Generates random time for repair.
   std::random_device rd;
   std::mt19937 gen(rd());
   std::uniform_int_distribution duration_generator(repair_time - 5, repair_time);

   // the repair process starts here.
   int time_needed = duration_generator(gen);
   // logging the status:
   std::cout << yellow << "[Repair]"
             << reset << " | "
             << blue << "[Status]"
             << reset << " -> "
             << red << "[Repairing]"
             << reset << " | "
             << bright_cyan << "[Drone] -> (" << id << ")"
             << reset << " | "
             << bright_white << "[Duration] -> " << time_needed << " sec\n"
             << std::flush;
   std::this_thread::sleep_for(std::chrono::seconds(time_needed));

   // the repair process has been ended
   distance_traveled = 0.0;
   current_load = 0.0;
   loaded_goods.clear();

   std::cout << yellow "[Repair]"
      << reset << " | "
      << blue << "[Status]"
      << reset << " -> "
      << red << "[Done]"
      << reset << " | "
      << bright_cyan << "[Drone] -> (" << id << ")"
      << reset << std::flush;
}

// getters
int Drone::get_id() const
{
    return id;
}
std::string Drone::get_type() const
{
    return type;
}
float Drone::get_max_distance() const
{
    return max_distance;
}
float Drone::get_max_capacity() const
{
    return max_capacity;
}
float Drone::get_speed() const
{
    return speed;
}

std::shared_ptr<Node> Drone::get_next_destination()
{
    return next_destination;
}
std::shared_ptr<Node> Drone::get_landed_node()
{
    return landed_node;
}
void Drone::set_next_destination(std::shared_ptr<Node> next_dest)
{
   next_destination = next_dest;
}

// operators
bool Drone::operator==(const Drone& other) const
{
    return other.get_id() == id && other.get_type() == type
        && other.get_max_distance() == max_distance
        && other.get_max_capacity() == max_capacity
        && other.get_speed() == speed; 
}