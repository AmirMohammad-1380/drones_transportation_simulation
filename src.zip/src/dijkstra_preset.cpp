#include "dijkstra_preset.hpp"

City::City() = default;

City::City(std::shared_ptr<Node> node, std::shared_ptr<Node> prev, float estimate, bool explored,
           std::vector<std::shared_ptr<Node>> neighbors)
           : node(node), prev(prev), estimate(estimate), explored(explored), neighbors(neighbors) {}

std::size_t Hash_Key::operator()(const std::shared_ptr<Node>& node) const
{
    return std::hash<uint16_t>()(node->get_id());
}

bool Hash_key_equality_check::operator()(const std::shared_ptr<Node>& lhs, const std::shared_ptr<Node>& rhs) const
{
    return lhs->get_id() == rhs->get_id();
}

std::unordered_map<std::shared_ptr<Node>, City, Hash_Key, Hash_key_equality_check> CITIES;