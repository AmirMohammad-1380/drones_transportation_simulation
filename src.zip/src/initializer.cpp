#include "../include/initializer.hpp"

std::string hub = "hub";

Initializer::Initializer(State& state) : state(state)
{
   load_cities();      // Reading the cities from csv file and load them to the program
   load_distances();   // Reading the graph from csv file and load the relation between the cities, aka nodes.
   dijkstra_init();    // Builds a proper graph for dijkstra's routing algorithm based on the loaded graph of the cities.
   initial_drones();   // initialize predefined numbers of drones for each city.
   initial_goods();    // initializes a predefined number of goods for the beginning of the simulation!

}

void Initializer::load_cities()  
{
    state.with_nodes([&](std::vector<std::shared_ptr<Node>> &nodes) -> void{
        std::vector<std::string> headers;
        std::ifstream cities_file(state.get_cities_source());
        try
        {
           // check if the file has been opened successfully.
           if (!cities_file.is_open()) {
              // Error - 1
              std::stringstream oss;
              oss << "[Error - 1: File] | Could not open the file: "  << state.get_cities_source();
              throw std::runtime_error(oss.str());
           }

           // Assistant variables to hold each line and cell.
           std::string line;  // to hold each returned line.
           std::string cell;  // to hold each returned cell.

           // creates our headers: id, name, type
           if (std::getline(cities_file, line)) {
              std::stringstream ss(line);    // convert the line to string stream type.
              while (std::getline(ss, cell, ',')) {
                 headers.push_back(cell);
              }
           }

           // looping through rest of the file to store the date.
           while (std::getline(cities_file, line)) {
              std::stringstream ss(line);    // convert the line to string stream type.
              uint8_t headers_size = headers.size();
              uint16_t id = 0;
              std::string name, type;
              for (uint8_t i = 0; i < headers_size && std::getline(ss, cell, ','); i++)
              {
                 if (headers[i] == "id") { // set the id for the city
                    id = static_cast<uint16_t>(std::stoul(cell));
                 } else if (headers[i] == "name") { //sets the name for the city
                    name = cell;
                 } else {    // sets the type for the city.
                    type = cell;
                 }
              }
              auto city = std::make_shared<Node>(id, name, type);
              nodes.emplace_back(std::move(city));
              // Adds the city to system_nodes
           }
        }
        catch(const std::exception& e)
        {
           std::cerr << e.what() << '\n';
        }
    });
}
void Initializer::load_distances()
{
   state.with_graph([&](Distance_matrix &graph, std::vector<std::shared_ptr<Node>> &nodes){
       // defines the system_graph here.
       uint16_t nodes_count = static_cast<uint16_t>(nodes.size());

       graph = Distance_matrix(nodes_count);

       std::vector<std::string> headers;   // a list to store all the headers of the csv file.
       try
       {
          std::ifstream graph_file(state.get_graph_source());
          if (!graph_file.is_open()) {
             // Error - 4
             std::stringstream error_message;
             error_message << "[Error - 4: file] | could not open the file: " << state.get_graph_source() << '\n';
             throw std::runtime_error(error_message.str());
          }

          // Assistant variables
          std::string line;   // to collect each line.
          std::string cell;   // to collect each cell.

          // collects the headers
          if (std::getline(graph_file, line))
          {
             std::stringstream ss(line);
             while (std::getline(ss, cell, ','))
             {
                headers.emplace_back(cell);
             }
          }

          // collects the data and makes the graph
          uint16_t origin_id, destination_id;
          float distance;
          while (std::getline(graph_file, line))
          {
             std::stringstream ss(line);
             for (int i = 0; i < headers.size() && std::getline(ss, cell, ','); i++)
             {
                if (headers[i] == "origin_id")
                {
                   origin_id = static_cast<uint16_t>(std::stoul(cell));
                }
                else if (headers[i] == "destination_id")
                {
                   destination_id = static_cast<uint16_t>(std::stoul(cell));
                }
                else
                {
                   distance = static_cast<float>(std::stof(cell));
                }
             }
             graph.set_distance(origin_id, destination_id, distance);
          }
       }
       catch (const std::exception& e)
       {
          std::cerr << e.what() << '\n';
       }
   });
}
void Initializer::initial_drones()
{
   state.with_drones([&](std::vector<std::shared_ptr<Drone>> &drones, std::vector<std::shared_ptr<Node>> &nodes){
       const auto& _config_ = state.get_config();

       // loops through the system_nodes to add drones there
       for (auto& node : nodes)
       {
          // generating the drones
          if (node->get_type() == _config_.node_config.type_hub) // if the node is hub
          {
             /* Hub type node must have two types of drones in their platform combined!
             * both Large and Medium drones */

             // creates large drones.
             for (int i = 0; i < _config_.node_config.hub_initial_large_drones; i++)
             {
                auto id = drone_id_generator(drones);
                auto type = _config_.drone_config.large.type_name;
                auto max_distance = _config_.drone_config.large.max_distance;
                auto max_capacity = _config_.drone_config.large.max_capacity;
                auto speed = _config_.drone_config.large.speed;

                // makes a shared_ptr<Drone> with type of large drones
                std::shared_ptr<Drone> large_drone;
                large_drone = std::make_shared<Drone>(id,
                                                      type,
                                                      max_distance,
                                                      max_capacity,
                                                      speed,
                                                      node,
                                                      state);

                drones.emplace_back(large_drone);
             }

             // creating medium drones for hub.
             for (int i = 0; i < _config_.node_config.hub_initial_medium_drones; i++)
             {
                // generating id
                int id = drone_id_generator(drones);
                auto type = _config_.drone_config.medium.type_name;
                auto max_distance = _config_.drone_config.medium.max_distance;
                auto max_capacity = _config_.drone_config.medium.max_capacity;
                auto speed = _config_.drone_config.medium.speed;

                // makes a shared_ptr<Drone> with type of large drones
                auto medium_drone = std::make_shared<Drone>(id, type,
                                                            max_distance,
                                                            max_capacity,
                                                            speed,
                                                            node,
                                                            state);

                // adding the drone to the proper lists, aka vectors.
                drones.emplace_back(medium_drone);
             }
          }
          else if (node->get_type() == _config_.node_config.type_sub_hub) // if the node is sub-hub
          {
             /* Sub-Hub type node must have two types of drones in their platform combined!
             * both Medium and Small drones */

             // creates medium drones.
             for (int i = 0; i < _config_.node_config.subhub_initial_medium_drones; i++)
             {
                // generates the unique id for the drone
                int id = drone_id_generator(drones);
                auto type = _config_.drone_config.medium.type_name;
                auto max_distance = _config_.drone_config.medium.max_distance;
                auto max_capacity = _config_.drone_config.medium.max_capacity;
                auto speed = _config_.drone_config.medium.speed;

                // creates an instance of medium drone
                auto medium_drone = std::make_shared<Drone>(id, type,
                                                            max_distance,
                                                            max_capacity,
                                                            speed,
                                                            node,
                                                            state);

                // adding drone to the proper list, aka vector.
                drones.emplace_back(medium_drone);
             }

             // creates small drones for sub-hub nodes
             for (int i = 0; i < _config_.node_config.subhub_initial_small_drones; i++)
             {
                // generates drone's id
                int id = drone_id_generator(drones);
                auto type = _config_.drone_config.small.type_name;
                auto max_distance = _config_.drone_config.small.max_distance;
                auto max_capacity = _config_.drone_config.small.max_capacity;
                auto speed = _config_.drone_config.small.speed;


                // creates an instance of small drone
                auto small_drone = std::make_shared<Drone>(id, type,
                                                           max_distance,
                                                           max_capacity,
                                                           speed,
                                                           node,
                                                           state);

                // adds the drone to a proper list, aka vector.
                drones.emplace_back(small_drone);
             }
          }
             // otherwise it is spoke node
          else
          {
             // generates small drones for the spokes
             for (int i = 0; i < _config_.node_config.spoke_initial_small_drone; i++)
             {
                // generates a unique if for the drone
                int id = drone_id_generator(drones);
                auto type = _config_.drone_config.small.type_name;
                auto max_distance = _config_.drone_config.small.max_distance;
                auto max_capacity = _config_.drone_config.small.max_capacity;
                auto speed = _config_.drone_config.small.speed;

                // makes a unique pointer to the generated drone
                auto small_drone = std::make_shared<Drone>(id, type,
                                                           max_distance,
                                                           max_capacity,
                                                           speed,
                                                           node,
                                                           state);
                drones.emplace_back(small_drone);
             }
          }
       }
   });
}
void Initializer::initial_goods()
{
   state.with_goods([&](std::vector<std::shared_ptr<Good>> &goods, std::vector<std::shared_ptr<Node>> &nodes){
       auto& _config_ = state.get_config();
       for (auto& node : nodes)
       {
          for (int i = 0; i < _config_.goods_per_node; i++)
          {
             int id = good_id_generator(goods);
             uint16_t orig_id = node_id_generator(nodes);
             uint16_t dest_id = node_id_generator(nodes);
             while (orig_id == dest_id)
             {
                dest_id = node_id_generator(nodes);
             }
             float weight = weight_generator();
             auto now = std::chrono::steady_clock::now();

             std::shared_ptr<Good> good = std::make_shared<Good>(id,
                                                                 random_node(orig_id, nodes),
                                                                 random_node(dest_id, nodes),
                                                                 weight,
                                                                 now,
                                                                 state);

             goods.emplace_back(good);
          }
       }
   });
}
int Initializer::drone_id_generator(std::vector<std::shared_ptr<Drone>> drones)
{
    // Generates random id for drones, an id between 0 and 10000 boundaries
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> id_generator(0, 10000);
    int id = 0;
    do 
    {
        id = id_generator(gen);
    } while (check_for_drone_id(id, drones));
    return id;
}
int Initializer::good_id_generator(std::vector<std::shared_ptr<Good>> goods)
{
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> id_generator(0, 10000000);

    int id = 0;
    do {
        id = id_generator(gen);
    }
    while (check_for_good_id(id, goods));
    return id;
}
std::shared_ptr<Node>& Initializer::random_node(uint16_t node_id, std::vector<std::shared_ptr<Node>> &nodes)
{
   /* finds the appropriate node with matching id */
   auto it = std::find_if(
      nodes.begin(), nodes.end(), [node_id](const std::shared_ptr<Node>& other_node){
         return node_id == other_node->get_id();
      }
   );

    /* if it could not find the matching node */
    if (it == nodes.end())
    {
       throw std::runtime_error("[Error - initializer.cpp - random_node()] | could not find the node!");
    }

   return *it;
}
uint16_t Initializer::node_id_generator(std::vector<std::shared_ptr<Node>> nodes)
{
   std::random_device rd;
   std::mt19937 gen(rd());
   int upper_bound = static_cast<int>(nodes.size());
   std::uniform_int_distribution<> id_gen(0, upper_bound - 1);
   return static_cast<uint16_t>(id_gen(gen));
 }
float Initializer::weight_generator()
{
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<> weight_generator(10.0, 100.0);

    return static_cast<float>(weight_generator(gen));

}
bool Initializer::check_for_drone_id(int id, std::vector<std::shared_ptr<Drone>> drones)
{
   return std::find_if(drones.begin(), drones.end(),
                       [id](const auto& drone) {return drone->get_id() == id;})
                       != drones.end();
}
bool Initializer::check_for_good_id(int id, std::vector<std::shared_ptr<Good>> goods)
{
   return std::find_if(goods.begin(), goods.end(),
                       [id](const auto& good) {return good->get_id() == id;})
                       != goods.end();

}

// Dijkstra's algorithm
void Initializer::dijkstra_init()
{
   state.with_graph([&](Distance_matrix &graph, std::vector<std::shared_ptr<Node>> &nodes){
       float INF = std::numeric_limits<float>::infinity();
       for (auto& node : nodes)
       {
          std::vector<std::shared_ptr<Node>> adj_list;
          for (auto& neighbor : nodes)
          {
             if (graph.is_adjacent(node->get_id(), neighbor->get_id()))
             {
                adj_list.push_back(neighbor);
             }
          }
          CITIES[node] = City{node, std::shared_ptr<Node>(), INF, false, std::move(adj_list)};
          adj_list.clear();
       }
   });
}