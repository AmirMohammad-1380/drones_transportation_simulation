#include "../include/distance_matrix.hpp"

// default constructor
Distance_matrix::Distance_matrix() : nodes(0) {}

// constructor
Distance_matrix::Distance_matrix(uint16_t& nodes) : nodes(nodes)
{
    adjacency_matrix = std::vector<std::vector<bool>>(nodes, std::vector<bool>(nodes, false));
}

// utility functions
bool Distance_matrix::is_adjacent(const uint16_t& u, const uint16_t& v)
{
    return adjacency_matrix[u][v];
}

// getters
float Distance_matrix::get_distance(const uint16_t& origin, const uint16_t& destination) const
{
    try
    {
        auto found = distance_matrix.find({origin, destination});
        if (found == distance_matrix.end()) {
            // Error - 2
            std::stringstream error_message;
            error_message << "[Error - 2: distance] | distance form [" << origin << "] to [" << destination <<"] could not be found\n";
            throw std::runtime_error(error_message.str());
        }
        return found->second;
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
        return -1.0;
    }  
}

// setters
void Distance_matrix::set_distance(uint16_t& origin, uint16_t& destination, float& distance)
{
    // sets the distance to the given pair of nodes, aka cities
    distance_matrix[{origin, destination}] = distance;
    distance_matrix[{destination, origin}] = distance;

    // sets the adjacency of the nodes
    adjacency_matrix[origin][destination] = true;
    adjacency_matrix[destination][origin] = true;
}