#ifndef NODE_HPP
#define NODE_HPP

#include "state.hpp"

#include <algorithm>
#include <cstdint>
#include <iostream> 
#include <memory>
#include <vector>

class Drone;
class Good;
class State;

class Node
{
public:
    // constructor 
    Node(uint16_t& id, std::string& name, std::string& type);

    // getters
    [[nodiscard]] const uint16_t& get_id() const;
    [[nodiscard]] const std::string& get_name() const;
    [[nodiscard]] const std::string& get_type() const;
    std::vector<std::shared_ptr<Drone>>& get_drones();

    // setters
    void set_id(uint16_t& id);
    void set_name(std::string& name);
    void set_type(std::string& type);

    // operators
    bool operator==(const Node& other);
    
private:
    uint16_t id;
    std::string name;
    std::string type;
    std::vector<std::shared_ptr<Drone>> drones;

    std::mutex lock_mutex_;
};

#endif