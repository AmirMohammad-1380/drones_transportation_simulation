#ifndef STATE_HPP
#define STATE_HPP

/* Costume libraries */
#include "drone.hpp"
#include "good.hpp"
#include "drone.hpp"
#include "distance_matrix.hpp"

/* C++ STL libraries */
#include <iostream>
#include <functional>
#include <mutex>
#include <memory>
#include <atomic>
#include <vector>

class State
{
public:
   // constructor: initializes the path of raw data.
   State(const std::string& cities_source, const std::string& graph_source);

   /* Config */
   struct Config
   {
       int goods_per_node = 30;

       struct Node_config
       {
           std::string type_hub = "hub";
           std::string type_sub_hub = "sub-hub";
           std::string type_spoke = "spoke";

           int hub_initial_large_drones = 20;
           int hub_initial_medium_drones = 20;
           int subhub_initial_medium_drones = 30;
           int subhub_initial_small_drones = 20;
           int spoke_initial_small_drone = 30;
       } node_config;

      struct Drone_config
      {
          struct Drone_type
          {
              std::string type_name;
              float max_distance;
              float max_capacity;
              float speed;
          } drone_type;

          Drone_type large{"large", 6400.0f, 20000.0f, 60.0f};
          Drone_type medium{"medium", 5000.0f, 15000.0f, 44.0f};
          Drone_type small{"small", 2000.0f, 9000.0f, 25.0f};
      } drone_config;
   };

   /* ********************************
    * Accessors: Thread-safe accessors
    * ******************************** */
   // resources
   template<typename Function>
   void with_nodes(Function function)
   {
      std::lock_guard<std::mutex> lock(nodes_mutex_);
      function(system_nodes);
   }

   template<typename Function>
   void with_goods(Function function)
   {
      std::lock_guard<std::mutex> lock(goods_mutex_);
      function(system_goods, system_nodes);
   }

   template<typename Function>
   void with_drones(Function function)
   {
      std::lock_guard<std::mutex> lock(drones_mutex_);
      function(system_drones, system_nodes);
   }

   template<typename Function>
   void with_graph(Function function)
   {
      std::lock_guard<std::mutex> lock(graph_mutex_);
      function(system_graph, system_nodes);
   }

   // flags
   std::atomic<bool>& get_running();
   std::atomic<bool>& get_paused();
   std::atomic<bool>& get_resumed();

   // data
   const std::string& get_cities_source();
   const std::string& get_graph_source();

   // config
   const Config& get_config() {return _config_;};

private:
   /* raw data */
   std::string cities_source_;
   std::string graph_source_;

   /* simulation handling flags */
   std::atomic<bool> running{true};
   std::atomic<bool> paused{false};
   std::atomic<bool> resumed{false};

   /* **************************************************
    * simulation resources and their guards, aka mutexes
    * ************************************************** */
   std::vector<std::shared_ptr<Node>> system_nodes;
   std::mutex nodes_mutex_;

   std::vector<std::shared_ptr<Good>> system_goods;
   std::mutex goods_mutex_;

   std::vector<std::shared_ptr<Drone>> system_drones;
   std::mutex drones_mutex_;

   /* map of the system, aka graph, and its guard which is mutex */
   Distance_matrix system_graph;
   std::mutex graph_mutex_;

   /* initialization phase variables */
   uint16_t number_of_nodes;

   Config _config_;
};

#endif