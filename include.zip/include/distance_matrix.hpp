#ifndef DISTANCE_MATRIX_HPP
#define DISTANCE_MATRIX_HPP

#include <iostream>
#include <stdexcept>
#include <sstream>
#include <unordered_map>
#include <utility>
#include <vector>

struct PairHash
{
    template<typename T1, typename T2>
    std::size_t operator()(const std::pair<T1, T2>& p) const
    {
        return std::hash<T1>{}(p.first) ^ (std::hash<T2>{}(p.second) << 1);
    }
};


class Distance_matrix
{
public:
    // defualt constructor
    Distance_matrix();

    // consructor
    Distance_matrix(uint16_t& nodes);

    // utility functions
    bool is_adjacent(const uint16_t& u, const uint16_t& v);

    // getters
    float get_distance(const uint16_t& origin, const uint16_t& destination) const;

    // setters
    void set_distance(uint16_t& origin, uint16_t& destination, float& distance);
    
private:
    uint16_t nodes;
    std::unordered_map<std::pair<uint16_t, uint16_t>, float, PairHash> distance_matrix;
    std::vector<std::vector<bool>>adjacency_matrix;
};

#endif