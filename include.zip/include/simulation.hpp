#ifndef SIMULATION_HPP
#define SIMULATION_HPP

// header files
#include "ThreadPool.hpp"
#include "state.hpp"
#include "timing.hpp"
#include "initializer.hpp"
#include "drones_tasks.hpp"

// standard C++ libraries
#include <iostream>
#include <vector>
#include <chrono>
#include <thread>
#include <atomic>

/* standard C libraries */
#include <stdio.h>

/* ANSI color codes */
#define reset "\033[0m"
#define red "\033[31m"
#define green "\033[32m"
#define yellow "\033[33m"
#define blue "\033[34m"
#define magenta "\033[35m"
#define cyan "\033[36m"
#define white "\033[37m"
#define bright_red "\033[91m"
#define bright_green "\033[92m"
#define bright_yellow "\033[93m"
#define bright_blue "\033[94m"
#define bright_magenta "\033[95m"
#define bright_cyan "\033[96m"
#define bright_white "\033[97m"


using namespace std::chrono_literals;

class Simulation
{
public:
    // constructor
    Simulation(int duration,
               std::string& cities_source,
               std::string& graph_source,
               size_t num_threads = std::thread::hardware_concurrency());

    void loading_process(std::shared_ptr<Node>& drone);

    void sim_run();

    void removal_process(std::vector<std::shared_ptr<Good>> to_remove, std::vector<std::shared_ptr<Good>> &goods);
    std::shared_ptr<Node> get_node_by_id(uint16_t node_id, std::vector<std::shared_ptr<Node>> &nodes);
    void remove_complete_deliverance_goods();
    void calculates_average_time();
    void redistrbute_drones();

private:
   State state;
   ThreadPool pool;
   Timing timer;
   Initializer init;

   // most important part! time estimation of goods delivery!
   std::vector<long> _deliverance_times;

   // for drones tasks of flights and loadings
   DronesTasks drone_task;

   /* mutex */
   std::mutex guard;
};

#endif