#ifndef THREADPOOL_HPP
#define THREADPOOL_HPP

#include <iostream>
#include <thread>
#include <memory>
#include <mutex>
#include <vector>
#include <queue>
#include <functional>
#include <condition_variable>
#include <future>

class ThreadPool
{
public:
    // constructor
    ThreadPool(size_t num_threads);

    // destructor
    ~ThreadPool();

    // ThreadPool shut down
    void ThreadPool_shutdown();

    // adds a task to the tasks queue
    template<class F, class... Args>
    auto enqueue(F&& f, Args&&... args) -> std::future<std::invoke_result_t<F, Args...>>
    {
        // deduce the task's return type
        using return_type = std::invoke_result_t<F, Args...>;

        // wraps a function task via packaged_task.
        auto task = std::make_shared<std::packaged_task<return_type()>>(
                std::bind(std::forward<F>(f), std::forward<Args>(args)...)
                );

        // gets the future and hold the result.
        std::future<return_type> res = task->get_future();

        // adds the task to the tasks queue
        {
            // locks the tasks queue to be thread safe
            std::unique_lock<std::mutex> lock(queue_mutex);

            if (stop)
            {
                throw std::runtime_error("could not add task while the pool has been stopped!");
            }

            // adds the task to the tasks queue sing a lambda function and transfer the ownership
            tasks.emplace([task = std::move(task)]() { (*task)(); });

        } // lock is released here automatically.

        // notify a thread that a task has been added to tasks queue
        condition.notify_one();

        return res;
    }
private:
    std::vector<std::thread> workers;
    std::queue<std::function<void()>> tasks;
    std::mutex queue_mutex;
    std::condition_variable condition;
    bool stop;
};

#endif