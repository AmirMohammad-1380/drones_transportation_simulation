#ifndef DIJKSTRA_PRESET_HPP
#define DIJKSTRA_PRESET_HPP

#include "node.hpp"

#include <memory>
#include <unordered_map>

// costume data type for towns in the Dijkstra's algorithm.
struct City
{
    // Default constructor
    City();

    // Constructor
    City(std::shared_ptr<Node> node, std::shared_ptr<Node> prev, float estimate, bool explored,
        std::vector<std::shared_ptr<Node>> neighbors);

    // Attributes
    std::shared_ptr<Node> node;
    std::shared_ptr<Node> prev;
    float estimate;
    bool explored;
    std::vector<std::shared_ptr<Node>> neighbors;
};

// The costume hash key for unordered map, aka hash table list of nodes in the system.
struct Hash_Key
{
    std::size_t operator()(const std::shared_ptr<Node>& node) const;
};

// The equality check of two hash keys passed by user to the hash table.
struct Hash_key_equality_check
{
    bool operator()(const std::shared_ptr<Node>& lhs, const std::shared_ptr<Node>& rhs) const;
};

// The hash table of the nodes in the system.
extern std::unordered_map<std::shared_ptr<Node>, City, Hash_Key, Hash_key_equality_check> CITIES;

#endif