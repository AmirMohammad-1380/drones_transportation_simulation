#ifndef INITIALIZER_HPP
#define INITIALIZER_HPP

#include "dijkstra_preset.hpp"
#include "state.hpp"
#include "drone.hpp"
#include "node.hpp"
#include "good.hpp"

#include <algorithm>
#include <chrono>
#include <fstream>
#include <iostream>
#include <memory>
#include <limits>
#include <random>
#include <sstream>
#include <stdexcept>
#include <vector>
#include <functional>

class State;
class Drone;
class Good;
class Node;

class Initializer
{
public:
    // constructor
    Initializer(State& state);

    // utility
    void load_cities();       // add the nodes, aka cities, from the csv source to memory, aka nodes vector.
    void load_distances();    // makes the connections between the cities, a weighted graph where weights are distances between each city.
    void initial_drones();    // initializes the drones
    void initial_goods();      // initializes the goods
    float weight_generator();
    int drone_id_generator(std::vector<std::shared_ptr<Drone>> drones); // generates a random id for drones.
    int good_id_generator(std::vector<std::shared_ptr<Good>> goods); // generates a random id for good.
    std::shared_ptr<Node>& random_node(uint16_t node_id, std::vector<std::shared_ptr<Node>> &nodes);
    uint16_t node_id_generator(std::vector<std::shared_ptr<Node>> nodes);
    bool check_for_drone_id(int id, std::vector<std::shared_ptr<Drone>> drones); // checks if the given id exists in the DRONE_IN_SYSTEM.
    bool check_for_good_id(int id, std::vector<std::shared_ptr<Good>> goods); //checks if the given id exists in the GOODS_IN_SYSTEM.

    // Dijkstra's Algorithm
    void dijkstra_init();

private:
    State& state;
};

#endif