#ifndef TIMING_HPP
#define TIMING_HPP

#include "state.hpp"

/* C++ libraries */
#include <iostream>
#include <atomic>
#include <chrono>

/* C libraries */
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

using namespace std::chrono_literals;

/* color's ANSI codes */
#define reset "\033[0m"
#define red "\033[31m"
#define green "\033[32m"
#define yellow "\033[33m"
#define blue "\033[34m"

class Timing
{
public:
    // constructor: takes the duration in seconds
    Timing(int duration,
           std::atomic<bool>& running,
           std::atomic<bool>& paused,
           std::atomic<bool>& resumed);

    // timer that begins counting forward the time in seconds!
    void tik_tok();

    // flags to make the timer stops, paused and resumed!
    void flags();

    // util: print function
    void print(const std::string& str, const char& color);
private:
    int duration;
    std::atomic<bool>& running, &paused, &resumed;
    std::mutex util_mutex;
};

#endif