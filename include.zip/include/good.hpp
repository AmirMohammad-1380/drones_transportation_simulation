#ifndef GOOD_HPP
#define GOOD_HPP

#include "state.hpp"
#include "dijkstra_preset.hpp"

#include <algorithm>
#include <chrono>
#include <iostream>
#include <sstream>
#include <limits>
#include <vector>
#include <queue>
#include <memory>


/* Note: the SHORT and TIME data types have been defined in the "custom_data.hpp" file! */

struct Path
{
    Path(uint16_t node_id, bool explored) : node_id(node_id), explored(explored) {}

    Path();

    uint16_t node_id;
    bool explored;
};

class Good
{
public:
    // constructor
    Good(int id,
         std::shared_ptr<Node>& origin_id,
         std::shared_ptr<Node>& destination_id,
         float weight,
         std::chrono::steady_clock::time_point generated_time,
         State& state);

    // utility function
    void generates_path(std::shared_ptr<Node>& origin, std::shared_ptr<Node>& destination);
    
    // getters
    [[nodiscard]] int get_id() const;
    [[nodiscard]] std::shared_ptr<Node>& get_origin() const;
    [[nodiscard]] std::shared_ptr<Node>& get_destination() const;
    [[nodiscard]] std::chrono::steady_clock::time_point get_generated_time() const;
    [[nodiscard]] float get_weight() const;
    [[nodiscard]] std::vector<Path>& get_path();
private:
    int id;
    std::shared_ptr<Node>& origin;
    std::shared_ptr<Node>& destination;
    float weight;
    std::chrono::steady_clock::time_point generated_time;
    std::vector<Path> path;

    State& state;
};

#endif