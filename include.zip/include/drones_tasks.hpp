#ifndef DRONES_TASKS_HPP
#define DRONES_TASKS_HPP

#include "node.hpp"
#include "good.hpp"

#include <memory>
#include <unordered_map>
#include <vector>

class DronesTasks
{
public:
    struct HashKey
    {
        std::size_t operator()(const std::shared_ptr<Node>& node) const
        {
           return std::hash<uint16_t>()(node->get_id());
        }
    } hash_key;
    struct HashEquality
    {
        bool operator()(const std::shared_ptr<Node> &lhs, const std::shared_ptr<Node> &rhs) const
        {
           return rhs->get_id() == lhs->get_id();
        }
    };
    struct Value
    {
        std::vector<std::shared_ptr<Good>> goods;
        bool delivered;
    } value;

    using InnerMap = std::unordered_map<
      std::shared_ptr<Node>,
      Value,
      HashKey,
      HashEquality>;

    using TasksMap = std::unordered_map<
      std::shared_ptr<Node>,
      InnerMap,
      HashKey,
      HashEquality>;

    TasksMap get_task_map()
    {
       return tasks_map;
    };
private:
   TasksMap tasks_map;
};

#endif