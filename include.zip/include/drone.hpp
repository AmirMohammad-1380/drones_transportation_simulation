#ifndef DRONE_HPP
#define DRONE_HPP

#include "state.hpp"

#include <cmath>
#include <sstream>
#include <iostream>
#include <memory>
#include <thread>
#include <random>
#include <vector>

class Node;
class Good;
class State;

/* ANSI color codes */
#define reset "\033[0m"
#define red "\033[31m"
#define green "\033[32m"
#define yellow "\033[33m"
#define blue "\033[34m"
#define magenta "\033[35m"
#define cyan "\033[36m"
#define white "\033[37m"
#define bright_red "\033[91m"
#define bright_green "\033[92m"
#define bright_yellow "\033[93m"
#define bright_blue "\033[94m"
#define bright_magenta "\033[95m"
#define bright_cyan "\033[96m"
#define bright_white "\033[97m"

class Drone
{
public:
    // constructor
    Drone(int id, const std::string& type, float max_distance, float max_capacity, float speed
        ,const std::shared_ptr<Node>& landed_node, State& state);

    // utility functions
    bool can_travel(float distance);                        // checks whether the drone can travel the passed distance the to function
    bool can_carry(float weight);                           // checks whether the drone can carry the passed weight the to function
    void load(std::shared_ptr<Good>& good);                 // loads a good into the drone.
    void delivery(float distance);                                        // delivers the goods from origin to destination.
    void travel(float distance);                                          // travel the passed distance to the function.
    void overhaul();                                        // fixes the out of service drone.
    void repair(int repair_time);                           // repairs a drone

    // Accessors
    [[nodiscard]] int get_id() const;
    [[nodiscard]] std::string get_type() const;
    [[nodiscard]] float get_max_distance() const;
    [[nodiscard]] float get_max_capacity() const;
    [[nodiscard]] float get_speed() const;
    [[nodiscard]] std::shared_ptr<Node> get_next_destination();
    [[nodiscard]] std::shared_ptr<Node> get_landed_node();

    void set_next_destination(std::shared_ptr<Node> next_dest);

    // operators
    bool operator==(const Drone& other) const;
    
private:
    int id;
    std::string type;
    float max_distance;
    float max_capacity;
    float speed;
    std::shared_ptr<Node> landed_node;
    std:: shared_ptr<Node> next_destination;
    float distance_traveled;
    float current_load;
    std::vector<std::shared_ptr<Good>> loaded_goods;

    std::mutex lock_mutex_;

    State& state;
};
#endif